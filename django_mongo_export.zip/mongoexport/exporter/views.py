from django.http import HttpResponse, FileResponse
from pymongo import MongoClient
import pandas as pd
from io import StringIO, BytesIO
from bson import ObjectId

client = MongoClient("mongodb://localhost:27017")
db = client["my_database"]
collection = db["my_collection"]

def build_filter_from_request(request):
    filter_dict = {}
    for k, v in request.GET.items():
        if k == "_id":
            try:
                filter_dict[k] = ObjectId(v)
            except:
                continue
        elif v.isdigit():
            filter_dict[k] = int(v)
        else:
            filter_dict[k] = v
    return filter_dict

def query_data(filter_dict):
    return list(collection.find(filter_dict))

def export_csv(request):
    filter_dict = build_filter_from_request(request)
    data = query_data(filter_dict)
    df = pd.DataFrame(data)
    buffer = StringIO()
    df.to_csv(buffer, index=False)
    buffer.seek(0)
    response = HttpResponse(buffer, content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="data.csv"'
    return response

def export_excel(request):
    filter_dict = build_filter_from_request(request)
    data = query_data(filter_dict)
    df = pd.DataFrame(data)
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename="data.xlsx",
                        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
