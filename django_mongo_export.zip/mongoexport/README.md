# Django Mongo Export Boilerplate

This Django project provides endpoints to export data from a MongoDB collection as `.csv` or `.xlsx` files using PyMongo and Pandas.

---

## 📦 Requirements

Install dependencies:

```bash
pip install django pymongo pandas openpyxl
```

---

## 🚀 Running the Project

```bash
cd django_mongo_export
python manage.py runserver
```

Visit:

- [http://localhost:8000/export/csv/](http://localhost:8000/export/csv/)
- [http://localhost:8000/export/xlsx/](http://localhost:8000/export/xlsx/)

---

## 🔍 Filtering MongoDB Results

You can filter documents via query parameters.

Examples:
- `/export/csv/?status=active`
- `/export/xlsx/?user_id=123`

---

## 🧱 Project Structure

```
mongoexport/
├── exporter/        # Your app
│   ├── views.py     # Export logic
│   └── urls.py      # Endpoint routing
├── mongoexport/     # Django project settings
│   ├── settings.py
│   └── urls.py
└── manage.py
```

---

## 🛠️ Customization

- Change MongoDB connection: `views.py`
- Update filters or parsing logic: `build_filter_from_request()`
- Add auth or permission logic as needed

---

## 📂 Notes

- Uses in-memory file buffers (`StringIO` / `BytesIO`)
- No temporary files written to disk
- Easily extendable to `.json`, `.xml`, or paginated exports
